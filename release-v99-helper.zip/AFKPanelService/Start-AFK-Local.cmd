@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Install Node.js 22 or newer first. & pause & exit /b 1)
if not exist node_modules\discord.js-selfbot-v13\package.json call npm ci --ignore-scripts --no-audit --no-fund
if errorlevel 1 (echo Could not install dependencies. & pause & exit /b 1)
if not exist afkpanel.local.json node configure.cjs
if errorlevel 1 (echo Could not set up the local service. & pause & exit /b 1)
echo AFK Panel local service. Leave this window open.
echo Your private service key is in afkpanel.local.json. Never share account tokens.
node server.cjs
pause
