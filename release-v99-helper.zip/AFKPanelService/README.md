# AFK Panel local companion

This companion runs on the same computer as Discord. It does not require a remote Lavalink server. Run Start-AFK-Local.cmd, keep its window open, and enter http://127.0.0.1:3847 and the apiKey from afkpanel.local.json into AFK Panel. Install Node.js 22+ if needed. Never share your account tokens or service key.

Personal-account automation violates Discord rules and can result in an account restriction; there is no guarantee against this. The underlying library is unsupported and the direct voice connection has only been tested with mocks. Camera and screen-share controls are experimental markers, not actual video streams. DM voice support depends on Discord and has not been tested with a live account.
